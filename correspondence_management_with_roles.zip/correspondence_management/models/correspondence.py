from odoo import models, fields, api, _

class CorrespondenceLetter(models.Model):
    _name = 'correspondence.letter'
    _description = 'Correspondence Letter'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Reference', required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))
    letter_type = fields.Selection([('in', 'Incoming'), ('out', 'Outgoing')], string='Type', required=True, default='in')
    subject = fields.Char(string='Subject', required=True, tracking=True)
    partner_id = fields.Many2one('res.partner', string='Partner', tracking=True)
    date = fields.Date(string='Date', default=fields.Date.context_today, tracking=True)
    body_html = fields.Html('Content')
    attachment_ids = fields.Many2many('ir.attachment', 'correspondence_attachment_rel', 'correspondence_id', 'attachment_id', string='Attachments')
    parent_id = fields.Many2one('correspondence.letter', string='Related Letter', tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('to_approve', 'To Approve'),
        ('approved', 'Approved'),
        ('sent', 'Sent'),
        ('received', 'Received'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], default='draft', tracking=True)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, readonly=True)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            seq_code = 'correspondence.sequence.out' if vals.get('letter_type') == 'out' else 'correspondence.sequence.in'
            vals['name'] = self.env['ir.sequence'].next_by_code(seq_code) or _('New')
        return super().create(vals)

    def action_print_letter(self):
        return self.env.ref('correspondence_management.report_correspondence').report_action(self)

    def action_send_letter(self):
        """
        Send the letter via email and mark it as sent.

        This action is intended to be called only once the letter has been
        approved. It sends the email using the configured mail template and
        updates the state to `sent`.
        """
        # Ensure we only send approved letters
        for rec in self:
            if rec.state not in ['approved', 'sent']:
                continue
            template = self.env.ref('correspondence_management.mail_template_correspondence_letter', raise_if_not_found=False)
            if template:
                template.send_mail(rec.id, force_send=True)
            rec.state = 'sent'
        return True

    def action_submit_for_approval(self):
        """
        Submit the letter for managerial approval.

        This method changes the state from draft to `to_approve`. It can be
        triggered by correspondence users to indicate that the document is
        ready for review.
        """
        for rec in self:
            if rec.state == 'draft':
                rec.state = 'to_approve'
        return True

    def action_approve(self):
        """
        Approve the letter.

        Managers invoke this method to approve a letter that is awaiting
        approval. Once approved, the letter can be sent by a manager.
        """
        for rec in self:
            if rec.state == 'to_approve':
                rec.state = 'approved'
        return True
